class NumeroPar //Crear un programa que lea un número e indique si es par o no 
{
    public int num1;
    public NumeroPar (int num1)
    {
        this.num1=num1;
    }
    public void Es_par()
    {
        if(num1%2==0)
        {
            Console.WriteLine("Es par");
        }
        else 
        Console.WriteLine("No es par");
    }
}