class MediaAritmetica //Programa que lea una serie de números (leer hasta que llegue el cero por ejemplo) y que calcule su media aritmética 
{
    public int numero{get;set;}
    public MediaAritmetica ()
    {
    }
    public void CalcularMediaAritmetica()
    {
        double promedio;
        int suma=0;
        int contador=0;
        do
        {
            Console.WriteLine("ingrese un numero: ");
            numero=int.Parse(Console.ReadLine());
            suma=numero+suma;
            contador++;
        }while(numero!=0);
        promedio=suma/contador;
        Console.WriteLine("El promedio de los numeros ingresados es : "+promedio);
    
       
    }

}

