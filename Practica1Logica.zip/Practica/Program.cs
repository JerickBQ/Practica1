﻿
Console.WriteLine("Hello, World!");
 NumeroM N1= new NumeroM (9, 6);
 N1.mayordelosdos();

// NumeroPar N2= new NumeroPar(100);
// N2.Es_par();

// Mayor N3=new Mayor(20, 50, 10);
// N3.mayordelostres();

// Indefinido N4 = new Indefinido ();
// N4.imprimir();

// SumadeNumeros N5 = new SumadeNumeros(2);
// N5.imprimir();

// SumadeNumerosMOD N6 =new SumadeNumerosMOD(4);
// N6.imprimir();

// TipodeTriangulo N7 = new TipodeTriangulo();
//    N7.imprimir();

// Multiplosde3 N7 =new Multiplosde3();
// N7.Multiplo();
 
//  MediaAritmetica  N8= new MediaAritmetica();
//  N8.CalcularMediaAritmetica();

// Factor N9 = new Factor ();
// N9.CalculodeFactorial();