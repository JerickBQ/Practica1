class SumadeNumeros //Escribir un programa que lea exactamente 8 números y luego escriba la suma de todos ellos
{
    public int numero;
    public SumadeNumeros (int numero)
    {
        this.numero=numero;
    }
    public void imprimir() 
    {
        int suma=0;
        for (int i = 0; i <= 7; i++)
        {
            Console.WriteLine("Ingrese un numero : ");
            numero= int.Parse( Console.ReadLine() );
            suma=suma+numero;
            
        }

        Console.WriteLine("La suma de los numeros ingresados es : "+suma);
        Console.ReadKey();
    }
}