class Factor //Programa que lea un número entero por teclado y que calcule su factorial.
{
    public int numero{get; set;}
    public Factor ()
    {
    }
    
    public void CalculodeFactorial ()
    {
        Console.WriteLine ("Ingrese el numero");
        int numero=Convert.ToInt32(Console.ReadLine());
        int factorial=1;
        for (int i = 1; i <= numero; i++)
        {
            factorial = factorial*i;
        }
        Console.WriteLine("El factorial de "+numero+ " es "+factorial);
        Console.ReadLine();
    }
}