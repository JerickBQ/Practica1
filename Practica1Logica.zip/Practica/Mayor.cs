class Mayor //Leer tres números y escribir el mayor de los tres
{
    public int numero1;
    public int numero2;
    public int numero3;
    public Mayor( int numero1, int numero2, int numero3)
    {
        this.numero1=numero1;
        this.numero2=numero2;
        this.numero3=numero3;
    }
    public void mayordelostres()
    {
        if ((numero1>numero2)&&(numero1>numero3))
        {            
            Console.WriteLine("el numero mayor de los tres numeros es: "+numero1);
        }else if ((numero2>numero1)&&(numero2>numero3))
        {
            Console.WriteLine("el numero mayor de los tres numeros es: "+numero2);
        }
        else
            Console.WriteLine("el numero mayor de los tres numeros es: "+numero3);
    }
}