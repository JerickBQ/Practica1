class Multiplosde3 //Escribir un programa que escriba todos los múltiplos de 3 del número 1 al 3000 
{
    public int i{get;set;}
    public Multiplosde3 ()
    {
        
    }
    public void Multiplo()
    {
        for (int i = 0; i <= 3000; i++)
        {
            if (i%3==0)
            {
                Console.WriteLine(i+"Es multiplo de 3");
            }
        }
    }
}