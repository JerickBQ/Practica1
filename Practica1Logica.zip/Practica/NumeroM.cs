class NumeroM //Crear un programa que lea dos números y que escriba el mayor de los dos.
{
    public int numero1;
    public int numero2;
    public NumeroM( int numero1, int numero2)
    {
        this.numero1=numero1;
        this.numero2=numero2;
    }
    public void mayordelosdos()
    {
        if (numero1>numero2)
        {
            Console.WriteLine("el numero mayor de los dos numeros es: "+numero1);
        }
        else
            Console.WriteLine("el numero mayor de los dos numeros es: "+numero2);

    }
}