class Indefinido //Escribir un programa que lea números enteros indefinidamente hasta que llegue el número 0
{
    public int numero;
    public Indefinido ()
    {
        
    }
    public void imprimir()
    {
        do
        {
            Console.WriteLine("ingrese un numero: ");
            numero=int.Parse(Console.ReadLine());
            int x=numero;

        }while(numero!=0);
    }
}