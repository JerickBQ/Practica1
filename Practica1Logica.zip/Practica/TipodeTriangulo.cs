class TipodeTriangulo
//Modificar el programa anterior para que en lugar de leer 8 números, se puedan leer tantos números como se quiera hasta que llegue un cero. 
//El resultado es la suma de todos los números leídos.
{
    public int lado1{get;set;}
    public int lado2{get;set;}
    public int lado3{get;set;}

    public TipodeTriangulo ()
    {
    
    }
    public void imprimir()
    {
        int opcion=0;

        do
        {
            Console.WriteLine("Ingrese un primer valor");
            lado1=int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un segundo valor");
            lado2=int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese un tercer valor");
            lado3= int.Parse(Console.ReadLine());

            Console.WriteLine("El triangulo que se forma con los datos ingresados es: ");
            if(lado1==lado2 && lado2==lado3)
            { 
                Console.WriteLine("Un triangulo equilatero"); 
            }
            if(lado1==lado2 && lado2!=lado3 || lado2==lado3 && lado3!=lado1 || lado3==lado1 && lado1!=lado2)
            { 
                Console.WriteLine("Un triangulo isosceles"); 
            }
            if(lado1!=lado2 && lado2!=lado3 && lado3!=lado1)
            {
                Console.WriteLine("Un triangulo escaleno"); 
            }
            Console.WriteLine("Continuar  1. S  o   2. N ");
            opcion=int.Parse(Console.ReadLine());
            
        } while (opcion!=2);
    }
    
}
