class SumadeNumerosMOD //Modificar el programa anterior para que en lugar de leer 8 números, se puedan leer tantos números como se quiera hasta que llegue un cero. 
//El resultado es la suma de todos los números leídos.
{
    public int numero{get; set;}
    public SumadeNumerosMOD (int numero)
    {
        this.numero=numero;
    }
    public void imprimir()
    {
        int suma=0;
        do
        {
            Console.WriteLine("Ingrese un numero : ");
            numero= int.Parse( Console.ReadLine() );
            suma=suma+numero;

        }while(numero!=0);

        Console.WriteLine("La suma de los numeros ingresados es : "+suma);
        Console.ReadKey();
    }
}